import ctypes
import os
import sys

# Try multiple locations to find the fluxdb compiled DLL
def _find_library():
    # 1. Look in the same directory as the module (for pip install)
    local_dir = os.path.dirname(os.path.abspath(__file__))
    
    if sys.platform == "win32":
        names = ["flux.dll", "libflux.dll"]
    elif sys.platform == "darwin":
        names = ["libflux.dylib"]
    else:
        names = ["libflux.so"]

    # Check local first
    for name in names:
        path = os.path.join(local_dir, name)
        if os.path.exists(path):
            if sys.platform == "win32" and hasattr(os, "add_dll_directory"):
                os.add_dll_directory(local_dir)
            return path
            
    # 2. Try falling back to system PATH 
    return names[0] # Let the OS try to find it

_lib_path = _find_library()

try:
    _lib = ctypes.CDLL(_lib_path)
except Exception as e:
    print(f"Failed to load FluxDB C++ Engine: {_lib_path}")
    print("Please ensure you have compiled the C++ engine (e.g. flux.dll) and placed it along this module or in your PATH.")
    raise Exception(f"Failed to load FluxDB library ({_lib_path}): {e}")

# Define C API types
class FluxDB_Handle(ctypes.Structure):
    pass

class FluxResult_Handle(ctypes.Structure):
    pass

# flux_init() -> FluxDB*
_lib.flux_init.argtypes = []
_lib.flux_init.restype = ctypes.POINTER(FluxDB_Handle)

# flux_query(FluxDB*, const char*) -> FluxResult*
_lib.flux_query.argtypes = [ctypes.POINTER(FluxDB_Handle), ctypes.c_char_p]
_lib.flux_query.restype = ctypes.POINTER(FluxResult_Handle)

# flux_result_get_text(FluxResult*) -> const char*
_lib.flux_result_get_text.argtypes = [ctypes.POINTER(FluxResult_Handle)]
_lib.flux_result_get_text.restype = ctypes.c_char_p

# flux_free_result(FluxResult*)
_lib.flux_free_result.argtypes = [ctypes.POINTER(FluxResult_Handle)]
_lib.flux_free_result.restype = None

# flux_close(FluxDB*)
_lib.flux_close.argtypes = [ctypes.POINTER(FluxDB_Handle)]
_lib.flux_close.restype = None

# flux_get_last_error() -> const char*
_lib.flux_get_last_error.argtypes = []
_lib.flux_get_last_error.restype = ctypes.c_char_p


class FluxError(Exception):
    pass

class FluxDB:
    """Pythonic wrapper around the FluxDB C API"""
    
    def __init__(self):
        self._db = _lib.flux_init()
        if not self._db:
            err = _lib.flux_get_last_error().decode('utf-8')
            raise FluxError(f"Initialization failed: {err}")

    def __del__(self):
        self.close()

    def close(self):
        if hasattr(self, '_db') and self._db:
            _lib.flux_close(self._db)
            self._db = None

    def query(self, sql: str) -> str:
        """Execute a GQL query and return the string result output"""
        if not self._db:
            raise FluxError("Database is closed")

        b_sql = sql.encode('utf-8')
        result_ptr = _lib.flux_query(self._db, b_sql)
        
        if not result_ptr:
            err = _lib.flux_get_last_error().decode('utf-8')
            raise FluxError(f"Query failed: {err}")

        text_output = _lib.flux_result_get_text(result_ptr).decode('utf-8')
        _lib.flux_free_result(result_ptr)
        
        return text_output

# Example Usage:
if __name__ == "__main__":
    db = FluxDB()
    print("Executing SPATIAL FIND query...")
    output = db.query("FIND entities NEAR (10.0, 0.0, 5.0) WITHIN 50.0 WHERE tag = 'enemy';")
    print(output)
    
    print("\nExecuting SPAWN query...")
    output2 = db.query("SPAWN PREFAB 'goblin' WITH health = 100, tag = 'enemy';")
    print(output2)
    
    db.close()
